import React from 'react'

export default function reportRow(props) {

    return (
        <div>
            <h1>{props.uqID}</h1>
        </div>
    )
}