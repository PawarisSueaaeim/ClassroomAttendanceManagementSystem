const hostIP = '10.80.124.43'

// const endpointWebApp = 'http://'+hostIP+':5000/studentchecking/us-central1/checkapp/webApp'
const endpointWebApp = 'https://us-central1-studentchecking.cloudfunctions.net/checkapp/webApp'


module.exports = {endpointWebApp}